"use strict";
/**
 * MONO-10 v0.11 — core/llm-capability.js  (§19)
 *
 * Une capacite LLM n'est jamais declaree : elle est CONSTATEE. AUCUN SECRET
 * n'est stocke ni journalise.
 *
 * Acquis v0.3 conserves : parseur strict a schema ferme, detection des cles
 * JSON dupliquees AVANT analyse, attestation explicite de non-elision des
 * identifiants, comparaison des trois identifiants de liaison.
 *
 * FERMETURE v0.4 (§19) : la sonde est liee au RUN ATTESTE. Un transport
 * fabrique localement sous un manifeste TEST ne peut jamais produire une
 * capacite utilisable en PRODUCTION — la classe de preuve vient de
 * l'attestation exterieure, pas de la sonde.
 */

const { sha256Of, isNonEmptyStr, fail } = require("./canonical.js");
const RM = require("./run-evidence-manifest.js");
const AC = require("./artifact-capabilities.js");
const AAR = require("./authenticated-artifact-registry.js");
const { artifactHash, bareArtifact } = require("./canonical.js");
const OTV = require("./operator-trust-verifier.js");
const OLB = require("./operator-llm-capability-boundary.js");

const STATUS = { DECLARED: "DECLARED", CONFIGURED: "CONFIGURED", PROBED: "PROBED", AVAILABLE: "AVAILABLE", DEGRADED: "DEGRADED", UNAVAILABLE: "UNAVAILABLE" };
const PROBE_STATUS = { SUCCESS: "SUCCESS", HTTP_ERROR: "HTTP_ERROR", SCHEMA_MISMATCH: "SCHEMA_MISMATCH", TIMEOUT: "TIMEOUT", NOT_RUN: "NOT_RUN" };
const PROBE_PROMPT = 'Reponds uniquement par cet objet JSON, sans aucun texte autour : {"ok":true,"probe":"evidenceforge"}';
const PROBE_MAX_TOKENS = 64;
const PROBE_SCHEMA_KEYS = ["ok", "probe"];

function readJsonString(text, i) {
  let out = ""; i++;
  while (i < text.length) {
    const c = text[i];
    if (c === "\\") {
      const n = text[i + 1];
      if (n === "u") { out += String.fromCharCode(parseInt(text.substr(i + 2, 4), 16)); i += 6; continue; }
      out += ({ n: "\n", t: "\t", r: "\r", b: "\b", f: "\f" })[n] || n; i += 2; continue;
    }
    if (c === '"') return { value: out, end: i + 1 };
    out += c; i++;
  }
  return { value: out, end: i, unterminated: true };
}

/** Scan du texte BRUT : `JSON.parse` effacerait silencieusement la duplication. */
function findDuplicateKeys(text) {
  const dups = [], stack = []; let i = 0;
  while (i < text.length) {
    const c = text[i];
    if (c === '"') {
      const s = readJsonString(text, i);
      if (s.unterminated) break;
      let j = s.end; while (j < text.length && /\s/.test(text[j])) j++;
      const top = stack[stack.length - 1];
      if (text[j] === ":" && top && top.type === "obj") {
        if (top.keys.has(s.value)) dups.push(s.value); else top.keys.add(s.value);
      }
      i = s.end; continue;
    }
    if (c === "{") { stack.push({ type: "obj", keys: new Set() }); i++; continue; }
    if (c === "[") { stack.push({ type: "arr" }); i++; continue; }
    if (c === "}" || c === "]") { stack.pop(); i++; continue; }
    i++;
  }
  return dups;
}

function validateProbePayload(text) {
  if (typeof text !== "string") return { valid: false, reason: "reponse non textuelle" };
  const trimmed = text.trim();
  if (!trimmed) return { valid: false, reason: "reponse vide" };
  if (trimmed[0] !== "{" || trimmed[trimmed.length - 1] !== "}") return { valid: false, reason: "texte avant ou apres l'objet JSON — schema ferme exige" };
  const dups = findDuplicateKeys(trimmed);
  if (dups.length) return { valid: false, reason: "cle(s) JSON dupliquee(s) : " + dups.join(", ") + " — une charge ambigue n'est pas une preuve" };
  let parsed;
  try { parsed = JSON.parse(trimmed); } catch (e) { return { valid: false, reason: "JSON invalide : " + e.message }; }
  if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) return { valid: false, reason: "objet JSON attendu" };
  const keys = Object.keys(parsed);
  const extra = keys.filter((k) => PROBE_SCHEMA_KEYS.indexOf(k) === -1);
  if (extra.length) return { valid: false, reason: "champ(s) supplementaire(s) : " + extra.join(", ") + " — schema ferme" };
  const missing = PROBE_SCHEMA_KEYS.filter((k) => keys.indexOf(k) === -1);
  if (missing.length) return { valid: false, reason: "champ(s) manquant(s) : " + missing.join(", ") };
  if (parsed.ok !== true) return { valid: false, reason: "ok doit valoir exactement true" };
  if (parsed.probe !== "evidenceforge") return { valid: false, reason: "probe inattendu" };
  return { valid: true, reason: null };
}

function readCredentialPresence(config) {
  const v = config ? config.credentialPresent : undefined;
  if (v === true || v === false) return { attested: v, problem: null };
  if (typeof v === "string") return { attested: false, problem: "credentialPresent doit etre un booleen. Une chaine a ete fournie — aucun secret n'est accepte ni stocke." };
  return { attested: false, problem: "credentialPresent absent : la presence d'identifiant n'est pas attestee." };
}

/**
 * runActiveProbe(intent, ctx)   (§45, §46)
 *
 * FERMETURE v0.5 B13. Le transport n'est plus un parametre : il vient de la
 * frontiere de capacite provisionnee par l'exploitant. L'appelant declare son
 * INTENTION (fournisseur, modele, worker attendus) ; il ne fournit pas la
 * fonction qui prouve son propre succes.
 *
 * Un `ctx.transport` fourni par l'appelant est IGNORE et signale.
 */
async function runActiveProbe(intent, ctx) {
  ctx = ctx || {}; const config = intent || {};
  const callerTransport = typeof ctx.transport === "function" || typeof ctx.callerTransport === "function";
  /**
   * §6/§11 (v0.10) — la frontiere de capacite n'est plus RECUPERABLE.
   *
   * v0.9 l'obtenait par `ctx.verifier.llmCapabilityBoundary()`, getter public :
   * l'audit A a recupere l'emetteur reel et minte une concession
   * `PRODUCTION_LLM_CAPABILITY` avec `derivationRef: "probe:jamais-execute"`.
   *
   * v0.10 : seul `verifier.runLlmProbe(config, ctx)` injecte `__llmBoundary`.
   * Un appelant qui appelle `runActiveProbe` directement n'a aucune frontiere :
   * la sonde est UNAVAILABLE, jamais optimiste.
   */
  const llmBoundary = ctx.__llmBoundary || null;
  const callerVerifierPresented = !!ctx.verifier && !OTV.isOperatorTrustVerifier(ctx.verifier);
  const transport = (llmBoundary && typeof llmBoundary.probe === "function")
    ? function (req) { return llmBoundary.probe(req); } : null;
  const cred = readCredentialPresence(config);
  const mode = RM.effectiveMode(ctx);
  const base = {
    schema: "EvidenceForge.LlmCapability", schemaVersion: "MONO-10-v6",
    providerId: config.providerId || null, modelId: config.modelId || null,
    workerBindingId: config.workerBindingId || null, authMode: config.authMode || null,
    configurationPresent: !!(isNonEmptyStr(config.providerId) && isNonEmptyStr(config.modelId) && isNonEmptyStr(config.workerBindingId)),
    credentialPresenceAttested: cred.attested, credentialPresenceProblem: cred.problem,
    credentialProbeSkipped: null, credentialProbeSkippedAttested: false,
    probeExecuted: false, probeStatus: PROBE_STATUS.NOT_RUN, probeTimestamp: null,
    requestId: null, responseSchemaValidated: false, capabilities: [], costUsd: null,
    /** §19 — la classe de preuve vient du run atteste, jamais de la sonde. */
    probeRunId: (ctx.manifest && ctx.manifest.runId) || null,
    probeExecutionMode: mode,
    probeAttestationHash: (ctx.manifest && ctx.manifest.runtimeAttestationHash) || null,
    probeContract: { promptShape: "closed-json-echo", maxTokens: PROBE_MAX_TOKENS, schemaKeys: PROBE_SCHEMA_KEYS, usesMissionData: false, usesCaseData: false },
    /** §45 — d'ou vient le transport. Un transport d'appelant n'en est pas un. */
    transportOrigin: llmBoundary ? llmBoundary.provisionedFrom : null,
    llmBoundaryId: llmBoundary ? llmBoundary.llmBoundaryId : null,
    llmBoundaryNamespace: llmBoundary ? llmBoundary.namespace : null,
    callerTransportIgnored: callerTransport === true,
    callerVerifierIgnored: callerVerifierPresented === true,
    /**
     * §3/§8 (v0.11) — reference de la SONDE inscrite au registre de l'emetteur.
     * Ce n'est PAS une decision certifiante : elle ne prouve rien a elle seule.
     * La decision n'est inscrite qu'a la certification, quand l'artefact existe
     * et que son sujet a ete compare au sujet reellement sonde.
     */
    probeRef: null,
    failureReason: null, status: STATUS.DECLARED,
  };
  if (!llmBoundary || !OLB.isProvisionedLlmBoundary(llmBoundary)) {
    base.status = STATUS.UNAVAILABLE;
    base.failureReason = "aucune frontiere de capacite LLM provisionnee par l'exploitant"
      + (callerTransport ? " ; un transport fourni par l'appelant a ete ignore" : "") + " — fail closed.";
    return base;
  }
  if (mode === RM.MODE.PRODUCTION && llmBoundary.namespace !== RM.MODE.PRODUCTION) {
    base.status = STATUS.UNAVAILABLE;
    base.failureReason = "frontiere de capacite en espace " + llmBoundary.namespace + " : elle ne prouve aucune capacite de PRODUCTION.";
    return base;
  }
  if (!base.configurationPresent) {
    base.status = STATUS.UNAVAILABLE;
    base.failureReason = "configuration incomplete : providerId, modelId et workerBindingId sont tous requis.";
    return base;
  }
  base.status = STATUS.CONFIGURED;
  if (typeof transport !== "function") { base.status = STATUS.UNAVAILABLE; base.failureReason = "frontiere de capacite sans sonde."; return base; }

  base.probeTimestamp = new Date().toISOString();
  let r = null;
  try {
    r = await transport({ providerId: config.providerId, modelId: config.modelId, workerBindingId: config.workerBindingId,
      prompt: PROBE_PROMPT, maxTokens: PROBE_MAX_TOKENS, runId: base.probeRunId });
  } catch (e) {
    base.probeExecuted = true; base.probeStatus = PROBE_STATUS.TIMEOUT;
    base.status = STATUS.UNAVAILABLE; base.failureReason = String((e && e.message) || e); return base;
  }
  base.probeExecuted = true; base.status = STATUS.PROBED;
  base.requestId = (r && isNonEmptyStr(r.requestId)) ? r.requestId : null;
  base.costUsd = (r && typeof r.costUsd === "number") ? r.costUsd : null;
  if (r && r.denied === true) {
    base.probeStatus = PROBE_STATUS.HTTP_ERROR; base.status = STATUS.UNAVAILABLE;
    base.failureReason = "intention refusee par la frontiere de l'exploitant : " + (r.denyReasons || []).join(" ; ");
    return base;
  }
  if (r && typeof r.credentialProbeSkipped === "boolean") { base.credentialProbeSkipped = r.credentialProbeSkipped; base.credentialProbeSkippedAttested = true; }

  if (!r || r.httpStatus !== 200) {
    base.probeStatus = PROBE_STATUS.HTTP_ERROR; base.status = STATUS.UNAVAILABLE;
    base.failureReason = "HTTP " + ((r && r.httpStatus) || "?") + " (200 attendu)"; return base;
  }
  const v = validateProbePayload(r.text);
  base.responseSchemaValidated = v.valid;
  if (!v.valid) { base.probeStatus = PROBE_STATUS.SCHEMA_MISMATCH; base.status = STATUS.DEGRADED; base.failureReason = "reponse hors schema : " + v.reason; return base; }
  base.probeStatus = PROBE_STATUS.SUCCESS;
  base.capabilities = ["closed_json_response"];

  const missing = [];
  if (!isNonEmptyStr(base.requestId)) missing.push("requestId");
  if (!isNonEmptyStr(base.probeTimestamp) || isNaN(Date.parse(base.probeTimestamp))) missing.push("probeTimestamp");
  if (base.credentialProbeSkippedAttested !== true) missing.push("le transport n'atteste pas que la sonde a porte des identifiants (credentialProbeSkipped absent)");
  else if (base.credentialProbeSkipped !== false) missing.push("sonde executee sans identifiants (credentialProbeSkipped=true)");
  if (base.credentialPresenceAttested !== true) missing.push(cred.problem || "credentialPresenceAttested");
  if (missing.length) { base.status = STATUS.DEGRADED; base.failureReason = "preuve incomplete : " + missing.join(" ; ") + "."; return base; }
  /**
   * §3/§8 (v0.11) — la sonde REELLEMENT executee est consignee, avec le SUJET
   * EXACT sur lequel elle a porte. Cette consignation ne certifie rien : elle
   * sera confrontee, a la certification, au sujet que l'artefact declare.
   */
  base.status = STATUS.AVAILABLE;
  if (typeof llmBoundary.recordProbe === "function") {
    const rec = llmBoundary.recordProbe({ requestId: base.requestId, providerId: base.providerId,
      modelId: base.modelId, workerBindingId: base.workerBindingId, runId: base.probeRunId,
      missionHash: (ctx.manifest && ctx.manifest.missionHash) || null,
      probeTimestamp: base.probeTimestamp }, { status: STATUS.AVAILABLE, probeStatus: base.probeStatus });
    base.probeRef = rec.probeRef;
  } else {
    base.status = STATUS.DEGRADED;
    base.failureReason = "frontiere de capacite sans registre de decisions : la sonde ne peut pas etre attestee.";
  }
  return base;
}

/** assertCapabilityUsable(capability, config, ctx) */
function assertCapabilityUsable(capability, config, ctx) {
  ctx = ctx || {};
  const problems = [];
  if (!capability || capability.schema !== "EvidenceForge.LlmCapability") return { usable: false, problems: ["artefact LlmCapability absent"] };

  /**
   * §9/§10 (v0.11) — FERMETURE B10-02. LE CONTEXTE EST OBLIGATOIRE, TOUJOURS.
   *
   * v0.10 lisait ce que la capacite PRETEND : un artefact qui ne revendiquait
   * rien, presente avec un contexte VIDE, obtenait `usable = true` sur ses
   * seules proprietes declaratives. L'audit A l'a montre. Une API publique de
   * validation ne doit pas etre plus permissive que son consommateur critique,
   * et l'absence d'un composant de securite requis est elle-meme une erreur.
   *
   * v0.11 exige, dans TOUS les espaces :
   *   - un verificateur issu d'une frontiere operateur ;
   *   - un registre d'artefacts AUTHENTIFIE ;
   *   - un mode d'execution attendu, lisible sur ce registre ;
   *   - une identite de frontiere COMPLETE (identifiant + liaison de config) ;
   *   - l'artefact REELLEMENT enregistre ;
   *   - un sujet de sonde verifie aupres de l'emetteur.
   *
   * Aucune de ces conditions ne se desactive en retirant le champ qui la porte.
   */
  const reg0 = ctx.artifactRegistry;
  const regOk = AAR.isAuthenticatedRegistry(reg0);
  const verifierOk = OTV.isOperatorTrustVerifier(ctx.verifier);
  const bi = regOk ? (reg0.boundaryIdentity || {}) : {};
  const expectedMode = regOk ? reg0.executionMode : ((ctx.manifest && ctx.manifest.executionMode) || null);
  if (!verifierOk) {
    problems.push("aucun verificateur issu d'une frontiere operateur au contexte : une capacite ne s'evalue pas "
      + "hors de la frontiere qui a ouvert le run — fail closed.");
  }
  if (!regOk) {
    problems.push("aucun registre d'artefacts AUTHENTIFIE au contexte : une capacite ne s'evalue pas hors du "
      + "registre du run — fail closed.");
  }
  if (!isNonEmptyStr(expectedMode)) {
    problems.push("aucun mode d'execution attendu derivable du contexte — fail closed.");
  }
  if (!isNonEmptyStr(bi.operatorBoundaryId) || !isNonEmptyStr(bi.configBindingHash)) {
    problems.push("identite de frontiere incomplete au contexte (identifiant et liaison de configuration "
      + "requis) — un identifiant declare seul ne prouve pas une origine.");
  }
  const artifactId0 = isNonEmptyStr(ctx.llmCapabilityArtifactId) ? ctx.llmCapabilityArtifactId : "llm-capability";
  if (regOk) {
    let entry0 = null;
    try { entry0 = reg0.get(artifactId0); } catch (e) { entry0 = null; }
    if (!entry0) {
      problems.push("l'artefact de capacite \"" + artifactId0 + "\" n'est pas enregistre dans le registre "
        + "authentifie de ce run : une capacite non enregistree n'est pas utilisable.");
    } else if (verifierOk && typeof ctx.verifier.verifyLlmSubject === "function") {
      /**
       * §6/§9 — le sujet DECLARE par l'artefact est confronte au sujet
       * REELLEMENT sonde, dans tous les espaces. C'est ce qui empeche une
       * sonde legitime de servir a certifier un fournisseur, un modele ou un
       * worker qui n'a jamais ete sonde (fermeture B10-01, volet consommateur).
       */
      const sub = ctx.verifier.verifyLlmSubject({ registry: reg0, artifactId: artifactId0 });
      if (!sub || sub.matches !== true) {
        problems.push("le sujet declare par l'artefact de capacite ne correspond pas au sujet reellement sonde : "
          + ((sub && sub.problems) || ["verification impossible"]).slice(0, 2).join(" ; "));
      }
    }
  }
  const genuineProduction = RM.isProductionContext(ctx);
  const claimsProduction = expectedMode === RM.MODE.PRODUCTION
    || capability.probeExecutionMode === RM.MODE.PRODUCTION
    || capability.llmBoundaryNamespace === RM.MODE.PRODUCTION
    || (ctx.manifest && ctx.manifest.executionMode === RM.MODE.PRODUCTION)
    || !!(ctx.artifactRegistry && ctx.artifactRegistry.executionMode === RM.MODE.PRODUCTION);
  if (claimsProduction && !genuineProduction) {
    problems.push("cette capacite pretend valoir en PRODUCTION mais le contexte presente ne permet pas de le "
      + "verifier (manifeste de run et verificateur de frontiere operateur de PRODUCTION requis) : "
      + "un controle qu'on ne peut pas mener est un refus, pas une dispense.");
  }
  const production = genuineProduction || claimsProduction;
  /**
   * §15/§16 (v0.9) — FERMETURE R4. En production, la capacite n'est utilisable
   * que si TOUT est reuni : registre AUTHENTIFIE, artefact REELLEMENT
   * enregistre, concession tracee, identite composite de frontiere.
   *
   * v0.8 sautait silencieusement le controle quand l'artefact n'etait pas
   * trouve : l'audit A a pointe un identifiant inexistant et obtenu
   * `usable = true`. Un controle conditionne a la presence de sa cible n'est
   * pas un controle.
   */
  if (production) {
    const reg = ctx.artifactRegistry;
    if (!AAR.isAuthenticatedRegistry(reg)) {
      problems.push("aucun registre d'artefacts AUTHENTIFIE dans le contexte : une capacite de production ne "
        + "s'evalue pas hors du registre du run — fail closed.");
    } else {
      const artifactId = artifactId0;
      let entry = null;
      try { entry = reg.get(artifactId); } catch (e) { entry = null; }
      if (!entry) {
        problems.push("l'artefact de capacite LLM \"" + artifactId + "\" n'est pas enregistre dans le registre "
          + "authentifie de ce run : une capacite non enregistree n'est pas utilisable.");
      } else if (artifactHash(entry.artifact) !== artifactHash(bareArtifact ? bareArtifact(capability) : capability)
        && entry.artifact.requestId !== capability.requestId) {
        problems.push("l'artefact de capacite presente ne correspond pas a celui enregistre sous \"" + artifactId + "\".");
      } else {
        const required = AC.requirementOf("llm-capability:production-use");
        try {
          AC.assertCapability(entry, required, "llm-capability:production-use",
            reg.boundaryIdentity || (ctx.manifest ? { operatorBoundaryId: ctx.manifest.operatorTrustBoundaryId,
              configBindingHash: ctx.manifest.configBindingHash, executionMode: ctx.manifest.executionMode } : null));
        } catch (err) {
          problems.push("capacite LLM de production refusee : " + String(err.message).slice(0, 200));
        }
      }
    }
  }
  if (production) {
    if (!ctx.manifest) problems.push("aucun manifeste de run : une capacite non rattachee a un run ne vaut pas en production");
    else {
      try { RM.assertProductionEvidence(capability, ctx, "LlmCapability"); } catch (e) { problems.push(e.message); }
      // §19 — la sonde doit avoir ete EXECUTEE sous ce run atteste.
      if (capability.probeRunId !== ctx.manifest.runId) problems.push("la sonde n'a pas ete executee sous ce run : probeRunId=" + capability.probeRunId);
      if (capability.probeAttestationHash !== ctx.manifest.runtimeAttestationHash) {
        problems.push("la sonde a ete executee sous une autre attestation runtime — une sonde de test ne prouve pas une capacite de production");
      }
      if (capability.probeExecutionMode !== RM.MODE.PRODUCTION) {
        problems.push("sonde executee en mode " + capability.probeExecutionMode + " : elle ne peut pas prouver une capacite de PRODUCTION");
      }
      // §45/§48 — le transport doit venir de l'exploitant, pas de l'appelant.
      if (capability.transportOrigin !== "ENVIRONMENT") {
        problems.push("transport de sonde d'origine \"" + capability.transportOrigin + "\" : une capacite de PRODUCTION exige un transport provisionne par l'exploitant");
      }
      if (capability.llmBoundaryNamespace !== RM.MODE.PRODUCTION) {
        problems.push("frontiere de capacite hors espace PRODUCTION");
      }
      if (capability.callerTransportIgnored === true) {
        problems.push("un transport fourni par l'appelant a ete presente : signale et ignore");
      }
      /**
       * §11/§12 (v0.10) — la sonde doit etre VERIFIABLE aupres de son emetteur.
       * Ni l'absence de reference, ni l'absence de verificateur ne valent
       * conformite : les deux refusent.
       */
      /**
       * §5/§6 (v0.11) — la DECISION certifiante est celle que porte la
       * concession, et elle est verifiee sur le SUJET COMPLET : fournisseur,
       * modele, worker, artefact, empreinte, run et mission.
       */
      if (!isNonEmptyStr(capability.probeRef)) {
        problems.push("aucune reference de sonde : une capacite de PRODUCTION non sondee n'existe pas — fail closed.");
      }
      let entryP = null;
      try { entryP = reg0 && reg0.get(artifactId0); } catch (e) { entryP = null; }
      const grantP = entryP && Array.isArray(entryP.capabilityGrants)
        ? entryP.capabilityGrants.filter(function (x) { return x && x.capability === AC.CAPABILITY.PRODUCTION_LLM_CAPABILITY; })[0]
        : null;
      if (!grantP) {
        problems.push("aucune concession PRODUCTION_LLM_CAPABILITY tracee sur cet artefact — fail closed.");
      } else if (!verifierOk) {
        problems.push("aucun verificateur pour verifier la decision " + String(grantP.derivationRef).slice(0, 40)
          + " — fail closed.");
      } else {
        const vd = ctx.verifier.verifyIssuerDecision("PRODUCTION_LLM_CAPABILITY", grantP.derivationRef,
          { decisionKind: "LLM_PROBE_EXECUTION", runId: ctx.manifest.runId,
            missionHash: ctx.manifest.missionHash, requestId: capability.requestId,
            artifactId: artifactId0, artifactHash: entryP.hash,
            providerId: capability.providerId, modelId: capability.modelId,
            workerBindingId: capability.workerBindingId,
            executionMode: RM.MODE.PRODUCTION });
        if (!vd || vd.valid !== true) {
          problems.push("decision de sonde " + String(grantP.derivationRef).slice(0, 40) + " non verifiable pour "
            + "CE sujet aupres de son emetteur : " + ((vd && vd.problems) || ["registre muet"]).slice(0, 2).join(" ; "));
        }
      }
    }
  }
  if (capability.status !== STATUS.AVAILABLE) problems.push("status=" + capability.status + " (AVAILABLE requis)");
  [["providerId", capability.providerId], ["modelId", capability.modelId], ["workerBindingId", capability.workerBindingId], ["requestId", capability.requestId]]
    .forEach(function (p) { if (!isNonEmptyStr(p[1])) problems.push(p[0] + " absent"); });
  if (!isNonEmptyStr(capability.probeTimestamp) || isNaN(Date.parse(capability.probeTimestamp))) problems.push("probeTimestamp absent ou invalide");
  if (capability.credentialPresenceAttested !== true) problems.push("credentialPresenceAttested != true");
  if (capability.probeExecuted !== true) problems.push("probeExecuted != true");
  if (capability.probeStatus !== PROBE_STATUS.SUCCESS) problems.push("probeStatus=" + capability.probeStatus);
  if (capability.responseSchemaValidated !== true) problems.push("responseSchemaValidated != true");
  if (capability.credentialProbeSkippedAttested !== true) problems.push("credentialProbeSkipped non atteste — absence != conformite");
  if (capability.credentialProbeSkipped !== false) problems.push("credentialProbeSkipped=" + String(capability.credentialProbeSkipped) + " (false explicite requis)");
  if (config) {
    [["providerId", "provider configure"], ["modelId", "modele configure"], ["workerBindingId", "binding d'execution configure"]]
      .forEach(function (p) {
        if (isNonEmptyStr(config[p[0]]) && capability[p[0]] !== config[p[0]]) {
          problems.push(p[0] + " different du " + p[1] + " : la capacite constatee ne porte pas sur ce qui sera execute");
        }
      });
  }
  return { usable: problems.length === 0, problems: problems };
}

function classifyLegacyDeclaration(dependenciesAvailable) {
  return { schema: "EvidenceForge.LlmCapability", schemaVersion: "MONO-10-v6",
    status: STATUS.DECLARED, probeExecuted: false, probeStatus: PROBE_STATUS.NOT_RUN,
    responseSchemaValidated: false, credentialPresenceAttested: false,
    credentialProbeSkipped: null, credentialProbeSkippedAttested: false,
    providerId: null, modelId: null, workerBindingId: null, requestId: null, probeTimestamp: null,
    probeRunId: null, probeExecutionMode: null, probeAttestationHash: null,
    legacyDeclaration: !!(dependenciesAvailable && dependenciesAvailable.llm === true),
    failureReason: "declaration du pilote d'execution, jamais une capacite constatee." };
}

module.exports = { runActiveProbe, assertCapabilityUsable, classifyLegacyDeclaration, validateProbePayload,
  findDuplicateKeys, readCredentialPresence, STATUS, PROBE_STATUS, PROBE_PROMPT, PROBE_MAX_TOKENS, PROBE_SCHEMA_KEYS };
