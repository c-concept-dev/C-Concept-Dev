"use strict";
/** MONO-11 v0.3-r1 — Autonomous Panel Successor (retry cible TARGET_REF_NOT_LITERAL + reuse de reparation limite au meme contexte semantique ; successeur de v0.3, lignee v0.2 gele). Compose MONO-10 v0.19, MONO-09 v0.2 et MONO-01 (geles) sans les modifier. */
module.exports = {
  frozenBridge: require("./core/frozen-bridge.js"),
  corpusSufficiencyProbe: require("./core/corpus-sufficiency-probe.js"),
  semanticRelevanceOracle: require("./core/semantic-relevance-oracle.js"),
  machineEvidenceGate: require("./core/machine-evidence-gate.js"),
  autonomousPanelAdapter: require("./core/autonomous-panel-adapter.js"),
  composedQualification: require("./core/composed-qualification.js"),
  ledger: require("./core/mono11-ledger.js"),
  llmResponseReuse: require("./core/llm-response-reuse.js"),
  autonomousRun: require("./core/autonomous-run.js"),
  targetNormalizer: require("./core/target-normalizer.js"),
  reviewEnforcer: require("./core/review-enforcer.js"),
  coverageEnforcer: require("./core/coverage-enforcer.js"),
  runSealGuard: require("./core/run-seal-guard.js"),
  contracts: require("./contracts/mono11-contracts.json"),
};
