"use strict";
/**
 * MONO-11 v0.1 — test/test-mono11-v0.2.js
 * Tests DISCRIMINANTS (Charte §23) : gate, anti-hardcoding, anti-circularite, lignee,
 * integrite des lots geles, fail-closed, mutation. Trois domaines synthetiques.
 * Aucune preuve REAL : les fixtures se declarent fixtures.
 */
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("fs"), path = require("path"), crypto = require("crypto");
const M11 = require("../index.js");
const { mountRun, bundleRoot } = require("./harness.js");
const { MISSIONS, makeFakeLlm } = require("./fixtures/domains.js");
const MEG = M11.machineEvidenceGate, APA = M11.autonomousPanelAdapter, Q = M11.composedQualification, SRO = M11.semanticRelevanceOracle, CSP = M11.corpusSufficiencyProbe;
const STATE = MEG.STATE;

const decisionOf = (r, suffix) => r.panel.decisions.find((d) => d.candidateId.endsWith("/" + suffix));
async function full(missionKey, opts) {
  const h = await mountRun(missionKey, opts);
  const r = await h.runPanel();
  return { h, r };
}

/* ===================== GATE (1-5) ===================== */
test("T01 identite forte + corpus suffisant + pertinence reelle -> AUTO_APPROVED", async () => {
  const { r } = await full("domainA");
  const d = decisionOf(r, "A-ok");
  assert.equal(d.state, STATE.APPROVED);
  assert.equal(d.relevanceClass, "SUPPORTED"); assert.equal(d.corpusStatus, "SUFFICIENT");
  assert.equal(d.machineActor.actorType, "machine"); assert.equal(d.notAHumanDecision.length > 0, true);
  assert.ok(d.criteria.find((c) => c.criterion === "G1_IDENTITY_RESOLVED").state === "SATISFIED");
  assert.ok(d.criteria.find((c) => c.criterion === "G3_REAL_RELEVANCE").state === "SATISFIED");
});
test("T02 identite ambigue -> AMBIGUOUS, jamais promu", async () => {
  const { r } = await full("domainA");
  const d = decisionOf(r, "A-amb");
  assert.equal(d.state, STATE.AMBIGUOUS);
  assert.ok(d.reasonCodes.includes("IDENTITY_AMBIGUOUS"));
  assert.equal(r.panel.approvedCandidateIds.includes(d.candidateId), false);
});
test("T03 corpus insuffisant -> INSUFFICIENT_DOCUMENTARY_BASIS, oracle non consulte", async () => {
  const { r } = await full("domainA");
  const d = decisionOf(r, "A-thin");
  assert.equal(d.state, STATE.INSUFFICIENT);
  assert.ok(d.reasonCodes.includes("CORPUS_INSUFFICIENT"));
  const g = r.gateInputs.find((x) => x.assessment.candidateId === d.candidateId);
  assert.equal(g.relevanceEvidence.oracle.realCall, false, "un corpus insuffisant ne coute aucun appel LLM");
});
test("T04 corpus hors mission -> AUTO_REJECTED (mission_irrelevant explicite sur chaque dimension)", async () => {
  const { r } = await full("domainA");
  const d = decisionOf(r, "A-off");
  assert.equal(d.state, STATE.REJECTED); assert.equal(d.relevanceClass, "OUT_OF_SCOPE");
});
test("T05 pertinence indeterminable -> AUTO_DEFERRED (terminal dans le run nominal)", async () => {
  const { r } = await full("domainA");
  const d = decisionOf(r, "A-und");
  assert.equal(d.state, STATE.DEFERRED); assert.equal(d.relevanceClass, "NOT_DETERMINABLE");
  assert.equal(APA.admittedCandidateIds(r.panel).includes(d.candidateId), false);
});

/* ===================== ANTI-HARDCODING (6-10) ===================== */
test("T06 trois missions de domaines distincts traversent la meme logique sans dictionnaire", async () => {
  for (const k of ["domainA", "domainB", "domainC"]) {
    const { r } = await full(k);
    assert.ok(r.panel.decisions.length > 0, k);
    r.panel.decisions.forEach((d) => assert.ok(M11.contracts.gateStates.values.includes(d.state), k + " " + d.state));
    assert.equal(r.panel.fixedQuota, false); assert.equal(r.panel.fixedPanelSize, false);
  }
  const { r: rb } = await full("domainB"); assert.equal(decisionOf(rb, "B-ok").state, STATE.APPROVED); assert.equal(decisionOf(rb, "B-partial").state, STATE.DEFERRED);
  const { r: rc } = await full("domainC"); assert.equal(decisionOf(rc, "C-ok").state, STATE.APPROVED); assert.equal(decisionOf(rc, "C-contra").state, STATE.AMBIGUOUS, "contradiction d'ORCID sur le corpus");
});
test("T07 permutation des candidats -> memes etats par candidat", async () => {
  const { r } = await full("domainA");
  const inputs = r.gateInputs.slice().reverse();
  const p2 = MEG.gatePanel({ candidates: inputs, dimensionSet: r.panel.dimensionSetRef && { dimensions: [] }, ctx: {} });
  const s1 = new Map(r.panel.decisions.map((d) => [d.candidateId, d.state])), s2 = new Map(p2.decisions.map((d) => [d.candidateId, d.state]));
  s1.forEach((v, k) => assert.equal(s2.get(k), v, k));
});
test("T08 changer les noms des candidats ne change aucun etat", async () => {
  const { r } = await full("domainA");
  const renamed = r.gateInputs.map((g, i) => Object.assign({}, g, { candidate: Object.assign({}, g.candidate, { displayName: "Autre nom " + i }), assessment: Object.assign({}, g.assessment, { professionalIdentity: { displayName: "Autre nom " + i } }) }));
  const p2 = MEG.gatePanel({ candidates: renamed, ctx: {} });
  r.panel.decisions.forEach((d, i) => assert.equal(p2.decisions[i].state, d.state));
});
test("T09 changer les libelles de discipline / lignee de requete n'a aucun effet decisif", async () => {
  const { r } = await full("domainA");
  const relabeled = r.gateInputs.map((g) => Object.assign({}, g, { candidate: Object.assign({}, g.candidate, { dimensionRef: "libelle-quelconque", disciplines: ["libelle-quelconque"] }) }));
  const p2 = MEG.gatePanel({ candidates: relabeled, ctx: {} });
  r.panel.decisions.forEach((d, i) => assert.equal(p2.decisions[i].state, d.state));
  const src = fs.readFileSync(path.join(__dirname, "..", "core", "machine-evidence-gate.js"), "utf8").replace(/\/\*[\s\S]*?\*\//g, "");
  assert.equal(/dimensionRef|disciplines|queryLineage/.test(src), false, "le gate ne lit ni dimensionRef ni disciplines ni lignee de requete");
});
test("T10 aucun quota : 0, 1 ou plusieurs admis sont tous des resultats legitimes ; scan anti-hardcoding vide", async () => {
  const { r } = await full("domainA");
  assert.ok(r.panel.approvedCandidateIds.length >= 1);
  const only = MEG.gatePanel({ candidates: r.gateInputs.filter((g) => g.assessment.candidateId.endsWith("/A-und")), ctx: {} });
  assert.equal(only.approvedCandidateIds.length, 0);
  assert.equal(only.counts.AUTO_DEFERRED, 1);
  const scan = require("../tools/anti-hardcoding-scan.js").scan();
  assert.deepEqual(scan.hits, [], JSON.stringify(scan.hits));
  ["FIXED_PROFESSION_LIST", "FIXED_DISCIPLINE_LIST", "FIXED_EXPERT_LIST", "FIXED_PANEL_SIZE", "CASE_SPECIFIC_LEAK_FOUND", "DOMAIN_HARDCODING_FOUND"].forEach((k) => assert.equal(scan[k], "NO", k));
});
test("T10b le scanner DETECTE une fuite plantee (mutation du balayage)", () => {
  const S = require("../tools/anti-hardcoding-scan.js");
  const tmp = path.join(__dirname, "..", "core", "__mutant-leak.js");
  /* le texte du mutant est ASSEMBLE pour ne pas figurer lui-meme dans ce fichier balaye */
  fs.writeFileSync(tmp, ["if (mission === '", "jm", "js') { panel", "Size = 5 }"].join("") + "\n");
  try {
    const scan = S.scan();
    assert.ok(scan.hits.some((h) => h.pattern === "IF_CASE"), "IF_CASE detecte");
    assert.equal(scan.CASE_SPECIFIC_LEAK_FOUND, "YES");
  } finally { fs.unlinkSync(tmp); }
});

/* ===================== ANTI-CIRCULARITE (11-14) ===================== */
test("T11 auteur d'une source incluse mais corpus hors mission -> rejete (etre auteur d'une source retenue ne prouve rien)", async () => {
  const { r } = await full("domainA");
  const d = decisionOf(r, "A-off");
  assert.equal(d.discoveryOrigin, "SEED_CANDIDATE"); assert.equal(d.state, STATE.REJECTED);
});
test("T12 auteur non-graine (decouverte secondaire) avec corpus pertinent -> peut etre retenu", async () => {
  const { r } = await full("domainA");
  const d = decisionOf(r, "A-second");
  assert.equal(d.discoveryOrigin, "DISCOVERED_CANDIDATE"); assert.equal(d.state, STATE.APPROVED);
  assert.ok(d.reasonCodes.includes("SECONDARY_DISCOVERY"));
});
test("T12b soutien par la seule oeuvre-graine -> SEED_ONLY_SUPPORT, AUTO_DEFERRED", async () => {
  const { r } = await full("domainA");
  const d = decisionOf(r, "A-seedonly");
  assert.equal(d.state, STATE.DEFERRED); assert.ok(d.reasonCodes.includes("SEED_ONLY_SUPPORT"));
});
test("T13 ORCID seul (sans corpus attribue) -> insuffisant", async () => {
  const { r } = await full("domainA");
  const d = decisionOf(r, "A-orcidonly");
  assert.equal(d.state, STATE.INSUFFICIENT); assert.ok(d.reasonCodes.includes("CORPUS_NOT_ATTRIBUTABLE") || d.reasonCodes.includes("NO_ATTRIBUTED_EVIDENCE"));
});
test("T14 forte citation sans pertinence -> insuffisant pour admettre ; le gate ne lit aucun compte de citations", async () => {
  const { r } = await full("domainA");
  assert.equal(decisionOf(r, "A-off").state, STATE.REJECTED);
  const src = fs.readFileSync(path.join(__dirname, "..", "core", "machine-evidence-gate.js"), "utf8").replace(/\/\*[\s\S]*?\*\//g, "");
  assert.equal(/citation|cited_by|h[_-]?index|popular/i.test(src), false);
});

/* ===================== LIGNEE (15-18) ===================== */
test("T15 casser une evidenceRef -> lignee invalide", async () => {
  const { h, r } = await full("domainA");
  assert.equal(h.ledger.verifyChain().valid, true);
  const art = h.ledger.get("mono11:relevance:" + decisionOf(r, "A-ok").candidateId);
  art.relevanceClass = "OUT_OF_SCOPE"; // mutation de l'artefact enregistre
  assert.equal(h.ledger.verifyChain().valid, false);
});
test("T16 casser la provenance -> gate INSUFFICIENT (G-11 UNKNOWN), jamais SATISFIED", async () => {
  const { r } = await full("domainA");
  const g = r.gateInputs.find((x) => x.assessment.candidateId.endsWith("/A-ok"));
  const broken = Object.assign({}, g, { evidenceArtifactRefs: { assessment: null, corpus: g.evidenceArtifactRefs.corpus, relevance: g.evidenceArtifactRefs.relevance } });
  const d = MEG.gateCandidate(broken);
  assert.equal(d.state, STATE.INSUFFICIENT); assert.ok(d.reasonCodes.includes("PROVENANCE_UNRESOLVED"));
});
test("T17 actorType human sans preuve humaine -> override refuse par le validateur GELE de MONO-10", async () => {
  const { h, r } = await full("domainA");
  const PG = h.M10.PG;
  const tpl = PG.buildPanelValidationTemplate(h.assessment);
  const fake = Object.assign({}, tpl, { decisions: tpl.decisions.map((d) => Object.assign({}, d, { decision: "APPROVE_FOR_DOCUMENTARY_PANEL", decisionReason: "x", actorType: "human", actorIdentity: "quelqu'un", decidedAt: new Date().toISOString(), decisionHash: "deadbeef", humanActProof: null })) });
  assert.throws(() => APA.applyHumanOverride({ frozen: h.F, panel: r.panel, panelValidation: fake, assessment: h.assessment, ctx: Object.assign({ artifactRegistry: h.registry }, h.ctx) }), /HUMAN_OVERRIDE_INVALID/);
  /* et un acte machine re-etiquete human est refuse par human-act.js (aucun mecanisme ne l'authentifie) */
  const asHuman = Object.assign({}, r.panel.decisions[0], { actorType: "human", actorIdentity: "machine deguisee", decidedAt: new Date().toISOString() });
  const auth = h.M10.CANON; void auth;
  const v = require(path.join(h.M10.dir, "core", "human-act.js")).verifyHumanActAuthenticity(asHuman, { verifier: h.verifier }, "test", { actionType: "PANEL_DECISION", decisionHash: r.panel.decisions[0].decisionHash, runId: h.runId, missionHash: h.missionHash });
  assert.equal(v.authenticated, false);
});
test("T18 acteur machine reel -> pass : identite du gate, hash du module, liaison au run", async () => {
  const { h, r } = await full("domainA");
  const a = r.panel.machineActor;
  assert.equal(a.actorType, "machine"); assert.equal(a.notAHumanAct, true);
  assert.ok(a.actorIdentity.startsWith("mono11-machine-evidence-gate@" + h.manifest.operatorTrustBoundaryId));
  assert.equal(a.gateModuleSha256, crypto.createHash("sha256").update(fs.readFileSync(path.join(__dirname, "..", "core", "machine-evidence-gate.js"))).digest("hex"));
  assert.equal(r.panel.runBinding.runId, h.runId);
  assert.equal(h.ledger.verifyChain().valid, true);
  assert.equal(h.registry.verifyEventChain().valid, true);
});

/* ===================== INTEGRITE DES LOTS GELES (19-20) ===================== */
test("T19 MONO-10 v0.19 : sceau 0 divergence, zip canonique intact", () => {
  const F = M11.frozenBridge.loadFrozen({ bundleRoot: bundleRoot() });
  assert.equal(F.seals.MONO10.verified, true); assert.equal(F.seals.MONO10.divergences.length, 0); assert.equal(F.seals.MONO10.files, 79);
  const zip = path.join(bundleRoot(), "MONO-10", "EvidenceForge-MONO10-SCIENTIFIC-QUALIFICATION-v0.19.zip");
  if (fs.existsSync(zip)) assert.equal(crypto.createHash("sha256").update(fs.readFileSync(zip)).digest("hex"), "f5a4165414f4aacc32f48f50eb14d59c87a09e3f138e24f8bd14b956972c2e04");
});
test("T20 tous les lots composes sont scelles ; un lot altere n'est PAS charge (mutation)", () => {
  const F = M11.frozenBridge.loadFrozen({ bundleRoot: bundleRoot() });
  assert.equal(F.seals.MONO09.verified, true); assert.equal(F.seals.MONO01.verified, true);
  const tmp = fs.mkdtempSync(path.join(require("os").tmpdir(), "m11-mut-"));
  const src = path.join(bundleRoot(), "MONO-09", "v0.2");
  fs.cpSync(src, path.join(tmp, "MONO-09", "v0.2"), { recursive: true });
  fs.cpSync(path.join(bundleRoot(), "MONO-10", "v0.19"), path.join(tmp, "MONO-10", "v0.19"), { recursive: true });
  fs.cpSync(path.join(bundleRoot(), "MONO-01"), path.join(tmp, "MONO-01"), { recursive: true });
  fs.appendFileSync(path.join(tmp, "MONO-09", "v0.2", "lib", "professional-adapter.js"), "\n// mutation\n");
  assert.throws(() => M11.frozenBridge.loadFrozen({ bundleRoot: tmp }), /FROZEN_LOT_ALTERED: MONO09/);
  fs.rmSync(tmp, { recursive: true, force: true });
});

/* ===================== FAIL-CLOSED (21-23) ===================== */
test("T21 0 eligible -> aucun faux panel : l'aval refuse", async () => {
  const { h, r } = await full("domainA");
  const empty = MEG.gatePanel({ candidates: r.gateInputs.filter((g) => g.assessment.candidateId.endsWith("/A-und")), ctx: h.gateCtx });
  await assert.rejects(h.runDownstream(Object.assign({}, r, { panel: empty })), /FAIL_CLOSED_NO_ADMITTED_PROFESSIONAL/);
  const q = Q.qualifyProcess({ frozen: h.F, assessment: h.assessment, panel: empty, corpusSet: { professionalCorpora: [] }, twinSet: { twins: [] }, reviewSet: { reviews: [] }, aggregation: { aggregates: [] }, llmCapability: {}, ledger: h.ledger, registry: h.registry });
  assert.equal(q.status, "NOT_QUALIFIED"); assert.ok(q.failedCriteria.includes("evidence_gate_passed"));
});
test("T22 0 jumeau -> pas de revue", async () => {
  const { h, r } = await full("domainA");
  const F = h.F; const orig = F.M01.E.buildDocumentaryTwinSet;
  const stub = Object.assign({}, F.M01.E, { buildDocumentaryTwinSet: async (i) => Object.assign(await orig(i), { twins: [], summary: { twinsBuilt: 0 } }) });
  const F2 = Object.assign({}, F, { M01: Object.assign({}, F.M01, { E: stub }) });
  await assert.rejects(h.runDownstream(r, { frozen: F2 }), /FAIL_CLOSED_NO_TWIN/);
});
test("T23 LLM indisponible -> pas de faux succes : oracle UNKNOWN, aucun admis ; capacite non prouvee -> NOT_QUALIFIED", async () => {
  const h = await mountRun("domainA", { llm: async () => { throw new Error("provider unavailable"); } });
  const r = await h.runPanel();
  assert.equal(r.panel.approvedCandidateIds.length, 0);
  r.gateInputs.filter((g) => g.corpusEvidence.status === "SUFFICIENT").forEach((g) => assert.equal(g.relevanceEvidence.relevanceClass, "UNKNOWN"));
  await assert.rejects(SRO.evaluateRelevanceEvidence({ frozen: h.F, corpus: { professionalRef: "x", corpus: { works: [] } }, attributedWorkRefs: [], dimensionSet: h.dimensionSet, missionQuestion: "q" }), /LLM_CALL_REQUIRED/);
  const { h: h2, r: r2 } = await full("domainA");
  const dn = await h2.runDownstream(r2);
  const q = Q.qualifyProcess({ frozen: h2.F, assessment: h2.assessment, panel: dn.panel, corpusSet: dn.corpusSet, twinSet: dn.twinSet, reviewSet: dn.reviewSet, aggregation: dn.aggregation,
    llmCapability: { schema: "EvidenceForge.LlmCapability", status: "AVAILABLE" }, llmConfig: {}, runContext: {}, ledger: h2.ledger, registry: h2.registry });
  assert.equal(q.status, "NOT_QUALIFIED"); assert.ok(q.failedCriteria.includes("llm_capability_validated"), "un booleen AVAILABLE sans sonde certifiee ne prouve rien");
});

/* ===================== ADVERSARIAL ORACLE / MUTATIONS ===================== */
test("T24 oracle menteur : titre invente -> refuse par le parseur gele, classe UNKNOWN, jamais admis", async () => {
  const h = await mountRun("domainA", { tamper: "invent_ref" });
  const r = await h.runPanel();
  const d = decisionOf(r, "A-ok");
  assert.notEqual(d.state, STATE.APPROVED); assert.equal(d.relevanceClass, "UNKNOWN");
});
test("T25 oracle incomplet (dimension manquante) et JSON casse -> UNKNOWN, jamais admis", async () => {
  for (const tamper of ["drop_dimension", "broken_json"]) {
    const h = await mountRun("domainA", { tamper });
    const r = await h.runPanel();
    assert.equal(r.panel.approvedCandidateIds.length, 0, tamper);
  }
});
test("T26 le gate refuse un artefact aval (G-7) et un etat hors contrat", async () => {
  const { r } = await full("domainA");
  assert.throws(() => MEG.gateCandidate(Object.assign({}, r.gateInputs[0], { reviewSet: { reviews: [] } })), /GATE_SEES_DOWNSTREAM/);
  assert.throws(() => MEG.gatePanel({ candidates: r.gateInputs, aggregation: {} }), /GATE_SEES_DOWNSTREAM/);
});
test("T27 politique de suffisance : seuils contractuels, jamais locaux ; un override est consigne", async () => {
  const F = M11.frozenBridge.loadFrozen({ bundleRoot: bundleRoot() });
  const p = CSP.resolveSufficiencyPolicy(F);
  assert.equal(p.policy.policyId, M11.contracts.corpusSufficiencyPolicy.policyId); assert.equal(p.policy.status, "test_unvalidated"); assert.equal(p.overridden, false);
  const o = CSP.resolveSufficiencyPolicy(F, { values: { minWorks: 5 } }); assert.equal(o.overridden, true); assert.equal(o.policy.values.minWorks, 5);
  assert.throws(() => CSP.resolveSufficiencyPolicy(F, { values: { minWorks: 0 } }), /min autoris/);
  const ev = CSP.probeCorpusSufficiency({ frozen: F, corpus: { professionalRef: "p", status: "complete", corpus: { works: [{ workRef: "w1", title: "t", doi: "10.5555/x", publicationYear: 2020, topics: [{ name: "a" }] }] } }, candidateRef: "p", attribution: null });
  assert.equal(ev.status, "UNKNOWN"); assert.ok(ev.reasonCodes.includes("CORPUS_NOT_ATTRIBUTABLE"));
});
test("T28 override humain authentifie : REJECT retire un admis, APPROVE sur AMBIGUOUS refuse, DEFER sans effet", async () => {
  const { h, r } = await full("domainA");
  const PG = h.M10.PG, HAP = require(path.join(h.M10.dir, "core", "human-act-proof.js")), OP = h.M10.OP;
  const tpl = PG.buildPanelValidationTemplate(h.assessment);
  const byId = new Map(h.assessment.assessments.map((a) => [a.candidateId, a]));
  const want = (id) => id.endsWith("/A-ok") ? "REJECT" : (id.endsWith("/A-amb") ? "APPROVE_FOR_DOCUMENTARY_PANEL" : "DEFER");
  const decisions = tpl.decisions.map(function (d) {
    const dec = want(d.candidateId); const dh = PG.panelDecisionHash(h.assessment, byId.get(d.candidateId), dec);
    return Object.assign({}, d, { decision: dec, decisionReason: "test override", actorType: "human", actorIdentity: "auditeur-panel", decidedAt: new Date().toISOString(), decisionHash: dh,
      humanActProof: OP.issueHumanActProof({ actorId: "auditeur-panel", actionType: HAP.ACTION_TYPE.PANEL_DECISION, decisionHash: dh, runId: h.runId, missionHash: h.missionHash, mechanismRef: h.verifier.humanAuthMechanismId(), actProofSecret: h.op.actProofSecret }) });
  });
  const validation = h.bind("panel-validation", h.R.PANEL_DECISION, Object.assign({}, tpl, { decisions }));
  h.verifier.certifyHumanAuthenticated({ registry: h.registry, artifactId: "panel-validation", acts: validation.decisions.map((d) => ({ act: d, expected: { actionType: HAP.ACTION_TYPE.PANEL_DECISION, decisionHash: d.decisionHash, runId: h.runId, missionHash: h.missionHash } })) });
  const p2 = APA.applyHumanOverride({ frozen: h.F, panel: r.panel, panelValidation: validation, assessment: h.assessment, ctx: Object.assign({ artifactRegistry: h.registry }, h.ctx) });
  /* A-amb n'est pas presentable a la porte MONO-10 (identite AMBIGUOUS => non PRESENT) : il n'y figure pas, donc aucun override ne peut l'admettre */
  assert.equal(APA.admittedCandidateIds(p2).some((id) => id.endsWith("/A-amb")), false);
  assert.equal(APA.admittedCandidateIds(p2).some((id) => id.endsWith("/A-ok")), false, "REJECT humain retire l'admis machine");
  assert.equal(p2.decisions.find((d) => d.candidateId.endsWith("/A-ok")).humanOverride.effect, "REMOVED_BY_HUMAN_OVERRIDE");
  assert.equal(p2.decisions.find((d) => d.candidateId.endsWith("/A-und")).humanOverride.effect, "NO_CHANGE_DEFER");
  assert.equal(p2.humanOverrideApplied, true);
  assert.equal(r.panel.humanOverrideApplied, false, "le panel machine n'est jamais mute");
});
test("T29 qualification : QUALIFIED_WITH_RESERVATIONS au mieux, reserve machine obligatoire, jamais QUALIFIED", async () => {
  const { h, r } = await full("domainA");
  const dn = await h.runDownstream(r);
  const cap = await h.llmCapability();
  const q = Q.qualifyProcess({ frozen: h.F, assessment: h.assessment, panel: dn.panel, corpusSet: dn.corpusSet, twinSet: dn.twinSet, reviewSet: dn.reviewSet, aggregation: dn.aggregation,
    llmCapability: cap.capability, llmConfig: cap.llmConfig, runContext: Object.assign({ artifactRegistry: h.registry }, h.ctx), ledger: h.ledger, registry: h.registry });
  assert.equal(q.status, "QUALIFIED_WITH_RESERVATIONS"); assert.deepEqual(q.failedCriteria, []);
  assert.equal(q.reservations[0].code, "PANEL_ADMITTED_BY_MACHINE_EVIDENCE_GATE_WITHOUT_HUMAN_ACT");
  assert.equal(q.humanPanelGateRequired, false);
  assert.ok(M11.contracts.qualificationStates.values.includes(q.status));
  const twins = dn.twinSet.twins.map((t) => t.professionalRef); const adm = APA.admittedCandidateIds(dn.panel);
  twins.forEach((t) => assert.ok(adm.includes(t), "jumeau hors panel"));
  assert.equal(q.criteria.find((c) => c.criterion === "no_human_act_simulated").pass, true);
});
test("T30 (v0.2) revue refusee localement -> reprise INFORMEE (passe 2 recoit erreurs + document) -> EF-03B gele accepte ; maxPasses=1 : l'erreur reste", async () => {
  const { h, r } = await full("domainA");
  const { makeDownstreamFakeLlm } = require("./harness.js");
  const flaky = makeDownstreamFakeLlm({ reviewTamper: "duplicate_dimension" });
  const dn = await h.runDownstream(r, { downstreamLlm: flaky, llmCall: flaky });
  assert.equal(dn.reviewSet.summary.reviewsError, 0);
  const t = dn.enforcementTraces.reviews.find((x) => x.acceptedPass === 2);
  assert.ok(t, "une revue a ete acceptee en passe 2");
  assert.ok(t.passes[0].errorCodes.includes("DIMENSION_DUPLICATE") && t.passes[0].errorCodes.includes("CARDINALITY"));
  const repair = flaky.calls.find((c) => c.indexOf("REPRISE (passe 2)") === 0 && c.indexOf("WORKS_USED") !== -1);
  assert.ok(repair.indexOf("[DIMENSION_DUPLICATE]") !== -1 && repair.indexOf("DOCUMENT CIBLE (targetId=") !== -1 && repair.indexOf("SCHEMA ATTENDU") !== -1 && repair.indexOf("CONTRAINTES DE CITATION") !== -1 && repair.indexOf("VOTRE REPONSE PRECEDENTE") !== -1, "la reprise voit erreurs, document, schema, contraintes, artefact fautif");
  const { h: h2, r: r2 } = await full("domainA");
  const flaky2 = makeDownstreamFakeLlm({ reviewTamper: "duplicate_dimension" });
  const dn2 = await h2.runDownstream(r2, { downstreamLlm: flaky2, llmCall: flaky2, reviewMaxPasses: 1 });
  assert.equal(dn2.reviewSet.summary.reviewsError, 1);
  const cap = await h2.llmCapability();
  const q = Q.qualifyProcess({ frozen: h2.F, assessment: h2.assessment, panel: dn2.panel, corpusSet: dn2.corpusSet, twinSet: dn2.twinSet, reviewSet: dn2.reviewSet, aggregation: dn2.aggregation,
    llmCapability: cap.capability, llmConfig: cap.llmConfig, runContext: Object.assign({ artifactRegistry: h2.registry }, h2.ctx), ledger: h2.ledger, registry: h2.registry });
  assert.equal(q.status, "NOT_QUALIFIED"); assert.ok(q.failedCriteria.includes("reviews_complete"));
});

/* ===================== v0.2 — NORMALISATION (mandat §9 : 1-4) ===================== */
const TN = M11.targetNormalizer, RE = M11.reviewEnforcer, CE = M11.coverageEnforcer, SG = M11.runSealGuard, RU = M11.llmResponseReuse;
const TYPO = "Passage un du document cible synth\u00e9tique : l\u2019absence de r\u00e9ponse ne vaut pas r\u00e9ponse n\u00e9gative. Passage deux, \u00ab cit\u00e9 \u00bb.";
test("T31 U+2019 dans le document, U+0027 dans la citation -> meme validation (normalisation a l'ingestion, EF-03B gele inchange)", async () => {
  const { h, r } = await full("domainA");
  const { makeDownstreamFakeLlm } = require("./harness.js");
  const llm = makeDownstreamFakeLlm({ reviewTamper: "ascii_apostrophe" });
  const dn = await h.runDownstream(r, { downstreamLlm: llm, llmCall: llm, targetContent: TYPO });
  assert.equal(dn.reviewSet.summary.reviewsError, 0, "la citation ASCII est acceptee parce que le document a ete normalise");
  assert.ok(dn.enforcementTraces.reviews.every((t) => t.acceptedPass === 1), "aucune reprise necessaire");
  /* contre-preuve : sans normalisation, le validateur gele refuse la citation ASCII contre le document U+2019 */
  const twin = dn.twinSet.twins[0]; const docRaw = { targetId: "target-01", role: "review_target_not_evidence", content: TYPO };
  const bad = JSON.stringify({ findings: dn.reviewSchema.dimensions.map((d) => ({ dimensionId: d.id, disposition: "concern", epistemicStatus: "not_determinable", finding: "x", rationale: "x", targetEvidenceRefs: ["l'absence de r\u00e9ponse"], twinBasisWorkRefs: [], confidenceQualitative: "low", limitations: [] })) });
  assert.throws(() => h.F.M01.RR.parseReviewResponse(bad, twin, docRaw, dn.reviewSchema), /targetEvidenceRef absent/);
  assert.equal(RE.validateReviewCandidate(bad, twin, docRaw, dn.reviewSchema).ok, false);
});
test("T32 original conserve, normalise hache, provenance verifiable, deterministe et idempotent", () => {
  const a = TN.normalizeTargetDocument({ targetId: "t", content: TYPO }), b = TN.normalizeTargetDocument({ targetId: "t", content: TYPO });
  assert.equal(a.record.original, TYPO); assert.equal(a.record.normalized.indexOf("\u2019"), -1); assert.ok(a.record.normalized.indexOf("l'absence") !== -1);
  assert.equal(a.record.normalizedSha256, b.record.normalizedSha256); assert.equal(a.record.originalSha256, crypto.createHash("sha256").update(TYPO, "utf8").digest("hex"));
  assert.equal(TN.normalizeText(a.record.normalized).normalized, a.record.normalized, "idempotent");
  assert.ok(a.record.transformations.find((t) => t.rule === "APOSTROPHE").occurrences === 1);
  assert.equal(a.record.normalized.indexOf("\u00ab"), a.record.original.indexOf("\u00ab"), "les guillemets francais ne sont pas touches");
  assert.equal(TN.verifyNormalizationRecord(a.record).valid, true);
  assert.equal(a.document.sourceDocumentRef, a.record.originalSha256); assert.ok(a.document.provenance.indexOf(a.record.normalizedSha256) !== -1);
});
test("T33 mutation du normaliseur detectee : texte normalise altere, ou regle qui changerait un mot", () => {
  const a = TN.normalizeTargetDocument({ targetId: "t", content: TYPO });
  const tampered = Object.assign({}, a.record, { normalized: a.record.normalized.replace("n\u00e9gative", "positive") });
  const v = TN.verifyNormalizationRecord(tampered); assert.equal(v.valid, false); assert.ok(v.problems.some((p) => /normalizedSha256/.test(p)));
  const tampered2 = Object.assign({}, a.record, { normalized: a.record.normalized + " " });
  assert.equal(TN.verifyNormalizationRecord(tampered2).valid, false);
  /* un mutant qui remplacerait un MOT serait une modification semantique : la longueur des regles est fermee et aucune ne contient de lettre */
  TN.RULES.forEach((r) => { if (r.re) assert.equal(/[a-zA-Z\u00C0-\u024F]/.test(r.re.source.replace(/\\u[0-9A-F]{4}|\\[rnt]/g, "")), false, "regle sans lettre : " + r.id); });
});

/* ===================== v0.2 — ENFORCEMENT EF-03B (5-9) ===================== */
test("T34 dimension dupliquee / cle additionnelle / cardinalite / enumeration -> FAIL local avant EF-03B", async () => {
  const { h, r } = await full("domainA"); const dn = await h.runDownstream(r);
  const twin = dn.twinSet.twins[0], doc = dn.targetDocumentSet.documents[0], sch = dn.reviewSchema;
  const ok = (over) => { const f = sch.dimensions.map((d) => ({ dimensionId: d.id, disposition: "concern", epistemicStatus: "not_determinable", finding: "x", rationale: "x", targetEvidenceRefs: [], twinBasisWorkRefs: [], confidenceQualitative: "low", limitations: [] })); return over ? over(f) : f; };
  assert.equal(RE.validateReviewCandidate(JSON.stringify({ findings: ok() }), twin, doc, sch).ok, true);
  const codes = (findings, root) => RE.validateReviewCandidate(JSON.stringify(Object.assign({ findings }, root || {})), twin, doc, sch).errors.map((e) => e.code);
  assert.ok(codes(ok((f) => f.concat([f[0]]))).includes("DIMENSION_DUPLICATE"));
  assert.ok(codes(ok((f) => { f[0].extra = 1; return f; })).includes("EXTRA_KEY"));
  assert.ok(codes(ok(), { autre: 1 }).includes("EXTRA_KEY"));
  assert.ok(codes(ok((f) => f.slice(1))).includes("CARDINALITY") && codes(ok((f) => f.slice(1))).includes("DIMENSION_MISSING"));
  assert.ok(codes(ok((f) => { f[0].disposition = "cautious_inference"; return f; })).includes("ENUM_DISPOSITION"));
  assert.ok(codes(ok((f) => { f[0].epistemicStatus = "documented"; return f; })).includes("DOCUMENTED_WITHOUT_TWIN_REF"));
  assert.ok(codes(ok((f) => { f[0].targetEvidenceRefs = ["passage invente"]; return f; })).includes("TARGET_REF_NOT_LITERAL"));
  assert.ok(codes(ok((f) => { f[0].twinBasisWorkRefs = ["oeuvre inconnue"]; return f; })).includes("TWIN_REF_UNKNOWN"));
});
test("T35 revue reparee valide -> EF-03B PASS ; refus persistant -> erreur, jamais forcee (fabrication maintenue)", async () => {
  const { makeDownstreamFakeLlm } = require("./harness.js");
  for (const tamper of ["extra_key", "bad_disposition"]) {
    const { h, r } = await full("domainA");
    const llm = makeDownstreamFakeLlm({ reviewTamper: tamper });
    const dn = await h.runDownstream(r, { downstreamLlm: llm, llmCall: llm });
    assert.equal(dn.reviewSet.summary.reviewsError, 0, tamper);
    assert.ok(dn.reviewSet.reviews.every((x) => x.enforcement.validatedBy.indexOf("EF-03B") !== -1));
  }
  const { h: h2, r: r2 } = await full("domainA");
  const llm2 = makeDownstreamFakeLlm({ reviewTamper: "invented_ref_forever" });
  const dn2 = await h2.runDownstream(r2, { downstreamLlm: llm2, llmCall: llm2 });
  assert.equal(dn2.reviewSet.summary.reviewsComplete, 0);
  dn2.enforcementTraces.reviews.forEach((t) => { assert.equal(t.acceptedPass, null); assert.equal(t.passes.length, 3); assert.ok(t.passes.every((p) => p.errorCodes.includes("TARGET_REF_NOT_LITERAL"))); });
});

/* ===================== v0.2 — ENFORCEMENT EF-02D3 (10-12) ===================== */
test("T36 theme cite comme oeuvre -> FAIL local ; workRef absent -> FAIL ; titre/DOI exact -> PASS ; reprise informee corrige", async () => {
  const { h, r } = await full("domainA");
  const corpus = r.corpusSetAll.professionalCorpora.find((c) => c.professionalRef.endsWith("/A-ok"));
  const dims = h.dimensionSet, L = h.F.M01.D3.LEVELS;
  const mk = (ev) => JSON.stringify({ professionalRef: corpus.professionalRef, dimensions: dims.dimensions.map((d, i) => ({ id: d.id, level: i === 0 ? "strong" : "absent", evidenceWorks: i === 0 ? ev : [], rationale: "x", contradictionWithMissing: false })), overallNote: "" });
  const codes = (t) => CE.validateCoverageCandidate(t, corpus, dims, L).errors.map((e) => e.code);
  assert.ok(codes(mk(["theme-A1"])).includes("THEME_LABEL_AS_WORK"));
  assert.ok(codes(mk(["Oeuvre qui n'existe pas"])).includes("WORKREF_UNRESOLVED"));
  assert.equal(CE.validateCoverageCandidate(mk([corpus.corpus.works[0].title]), corpus, dims, L).ok, true);
  assert.equal(CE.validateCoverageCandidate(mk([corpus.corpus.works[0].doi]), corpus, dims, L).ok, true);
  const { makeDownstreamFakeLlm } = require("./harness.js");
  const llm = makeDownstreamFakeLlm({ coverageTamper: "topic_as_work" });
  const dn = await h.runDownstream(r, { downstreamLlm: llm, llmCall: llm });
  const t = dn.enforcementTraces.coverage.find((x) => x.passes.length === 2);
  assert.ok(t && t.passes[0].errorCodes.includes("THEME_LABEL_AS_WORK") && t.acceptedPass === 2, "la couverture est reprise avec les references admissibles");
  assert.equal(dn.twinSet.blocked.length, 0, "aucun admis bloque par une couverture invalide");
  assert.equal(h.F.M01.D3.buildCoverageMatrix.toString().indexOf("MONO-11"), -1, "EF-02D3 gele n'est pas touche");
});

/* ===================== v0.2 — SCELLEMENT AVANT RUN (13-15) ===================== */
test("T37 code non scelle -> FAIL ; fichier scelle modifie -> FAIL ; sceau valide -> PASS avec hashes", () => {
  const os = require("os"); const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "m11-seal-"));
  const LOT = path.resolve(__dirname, "..");
  fs.cpSync(LOT, tmp, { recursive: true, filter: (src) => !/SHA256SUMS\.txt$|MANIFEST\.json$/.test(src) });
  assert.throws(() => SG.assertSealedRuntime({ lotDir: tmp }), /RUN_ON_UNSEALED_CODE.*aucun SHA256SUMS/);
  /* sceau construit sur la copie */
  const sealTool = require("child_process").spawnSync("node", [path.join(tmp, "tools", "seal.js")], { encoding: "utf8" }); assert.equal(sealTool.status, 0);
  fs.writeFileSync(path.join(tmp, "MANIFEST.json"), JSON.stringify({ version: "v0.2" }));
  const ok = SG.assertSealedRuntime({ lotDir: tmp, expectedVersion: "v0.2" });
  assert.equal(ok.sealed, true); assert.match(ok.runtimeSealSha256, /^[0-9a-f]{64}$/); assert.match(ok.runCodeHash, /^[0-9a-f]{64}$/); assert.match(ok.mono11ManifestSha256, /^[0-9a-f]{64}$/);
  fs.appendFileSync(path.join(tmp, "core", "machine-evidence-gate.js"), "\n// mutation\n");
  assert.throws(() => SG.assertSealedRuntime({ lotDir: tmp }), /RUN_ON_UNSEALED_CODE.*modifie/);
  fs.writeFileSync(path.join(tmp, "core", "unsealed-extra.js"), "module.exports = 1;\n");
  assert.throws(() => SG.assertSealedRuntime({ lotDir: tmp }), /NON scelle/);
  fs.rmSync(tmp, { recursive: true, force: true });
});

/* ===================== v0.2 — POLITIQUE DE REUSE (16-19) ===================== */
test("T38 reponse reelle VALID existante -> reuse ; reuse != REAL_LLM_CALL ; INVALID -> retry reel ; prompt different -> pas de reuse", () => {
  const store = RU.createMemoryStore(); const P = RU.createReusePolicy({ store });
  const prompt = "prompt A"; const resp = "reponse A";
  assert.equal(P.decide(prompt).decision, "REAL_CALL");
  const rec = P.recordReal({ promptSha256: P.sha(prompt), responseSha256: P.sha(resp), sourceRunId: "run-1", sourceCallId: "msg_1", providerRequestId: "msg_1", providerId: "p", modelId: "m", completedAt: "2026-01-01T00:00:00Z", httpStatus: 200 });
  assert.equal(P.decide(prompt).decision, "RETRY_REAL", "UNKNOWN (jamais validee) n'est pas reutilisee en silence");
  P.markValidation({ responseSha256: P.sha(resp), valid: true, stage: "EF-03B-local" });
  const d = P.decide(prompt); assert.equal(d.decision, "REUSE_VALID"); assert.equal(d.entry.sourceCallId, "msg_1");
  const rr = P.reuseRecord(d.entry, { runId: "run-2", reason: d.reason });
  assert.equal(rr.kind, "LLM_REUSE"); assert.equal(rr.countsAsRealCall, false);
  ["sourceRunId", "sourceCallId", "promptHash", "responseHash", "validationStatus", "reuseReason"].forEach((k) => assert.ok(rr[k], k));
  assert.equal(P.decide("prompt A ").decision, "REAL_CALL", "un octet de difference : aucune reutilisation silencieuse");
  P.markValidation({ responseSha256: P.sha(resp), valid: false, errors: ["SCHEMA"], stage: "EF-03B-local" });
  assert.equal(P.decide(prompt).decision, "RETRY_REAL");
  P.markValidation({ responseSha256: P.sha(resp), valid: true }); assert.equal(P.decide(prompt).decision, "RETRY_REAL", "une reponse refusee une fois reste refusee");
  const resp2 = "reponse B"; P.recordReal({ promptSha256: P.sha(prompt), responseSha256: P.sha(resp2), sourceRunId: "run-2", sourceCallId: "msg_2", completedAt: "2026-01-02T00:00:00Z", httpStatus: 200 });
  P.markValidation({ responseSha256: P.sha(resp2), valid: true }); assert.equal(P.decide(prompt).entry.sourceCallId, "msg_2", "la reponse valide la plus recente est reutilisee");
  const off = RU.createReusePolicy({ store, allowReuse: false }); assert.equal(off.decide(prompt).decision, "REAL_CALL");
});

/* ===================== v0.2 — GARDE reviews_complete = 100 % (20-23), lacune M9 fermee ===================== */
function synthReviewSet(n, complete) {
  const reviews = []; for (let i = 0; i < n; i++) reviews.push({ reviewStatus: i < complete ? "complete" : "error", twinId: "t" + (i % 10), targetId: "target-0" + (Math.floor(i / 10) + 1), findings: i < complete ? [{}] : [] });
  return { schema: "EvidenceForge.DocumentaryReviewSet", reviews, unresolvedTargets: [], summary: { twins: 10, targets: n / 10, reviewsExpected: n, reviewsComplete: complete, reviewsError: n - complete } };
}
test("T39 reviews_complete : 100/100 PASS ; 99/100, 90/100, 80/100 FAIL — cardinalite attendue, jamais un nombre en dur", () => {
  const rc = Q.reviewCardinality;
  assert.deepEqual(rc(synthReviewSet(100, 100), null), { accepted: 100, expected: 100, produced: 100 });
  const src = fs.readFileSync(path.join(__dirname, "..", "core", "composed-qualification.js"), "utf8").replace(/\/\*[\s\S]*?\*\//g, "").replace(/^\s*\/\/.*$/gm, "");
  assert.equal(/\b81\b/.test(src), false, "aucune cardinalite en dur");
  assert.equal(/0\.9|0\.8|0\.99|\* ?0\.|Math\.floor\(.*expected/.test(src), false, "aucun ratio de tolerance");
  assert.ok(/rc\.accepted === rc\.expected/.test(src), "la regle est une egalite stricte");
  const F = M11.frozenBridge.loadFrozen({ bundleRoot: bundleRoot() });
  const base = { frozen: F, assessment: { schema: "EvidenceForge.ProfessionalCandidateAssessment", assessments: [{ candidateId: "x" }], unknowns: [] },
    panel: { schema: "EvidenceForge.MachineEvidenceGatePanel", decisions: [{ candidateId: "x", state: "AUTO_APPROVED_FOR_DOCUMENTARY_PANEL", relevanceClass: "SUPPORTED", corpusStatus: "SUFFICIENT", reasonCodes: [], machineActor: { actorType: "machine", actorIdentity: "g" } }], machineActor: { actorType: "machine", actorIdentity: "g" }, reservations: [] },
    corpusSet: { professionalCorpora: [{ professionalRef: "x", status: "complete" }] }, twinSet: { twins: Array.from({ length: 10 }, (_, i) => ({ professionalRef: "x", twinId: "t" + i })) }, aggregation: { aggregates: [{}] }, llmCapability: {} };
  const status = (n, c) => Q.qualifyProcess(Object.assign({}, base, { reviewSet: synthReviewSet(n, c) })).criteria.find((x) => x.criterion === "reviews_complete").pass;
  assert.equal(status(100, 100), true); assert.equal(status(100, 99), false); assert.equal(status(100, 90), false); assert.equal(status(100, 80), false);
  assert.equal(status(30, 30), true); assert.equal(status(30, 29), false, "cardinalite legitimement differente : 100 % de 30");
});
test("T40 mutation : une tolerance 99 % / 90 % / 80 % injectee dans la regle est DETECTEE par T39 (garde M9)", () => {
  const vm = require("vm"); const srcPath = path.join(__dirname, "..", "core", "composed-qualification.js");
  const src = fs.readFileSync(srcPath, "utf8");
  const original = "rc.expected > 0 && rc.accepted === rc.expected";
  assert.ok(src.indexOf(original) !== -1);
  for (const tol of [0.99, 0.9, 0.8]) {
    const mutated = src.split(original).join("rc.expected > 0 && rc.accepted >= " + tol + " * rc.expected");
    const mod = { exports: {} };
    vm.runInThisContext("(function (require, module, exports, __dirname, __filename) {" + mutated + "\n})")(require, mod, mod.exports, path.dirname(srcPath), srcPath);
    const Qm = mod.exports;
    const F = M11.frozenBridge.loadFrozen({ bundleRoot: bundleRoot() });
    const base = { frozen: F, assessment: { schema: "EvidenceForge.ProfessionalCandidateAssessment", assessments: [{ candidateId: "x" }], unknowns: [] },
      panel: { schema: "EvidenceForge.MachineEvidenceGatePanel", decisions: [{ candidateId: "x", state: "AUTO_APPROVED_FOR_DOCUMENTARY_PANEL", relevanceClass: "SUPPORTED", corpusStatus: "SUFFICIENT", reasonCodes: [], machineActor: { actorType: "machine", actorIdentity: "g" } }], machineActor: { actorType: "machine", actorIdentity: "g" }, reservations: [] },
      corpusSet: { professionalCorpora: [{ professionalRef: "x", status: "complete" }] }, twinSet: { twins: Array.from({ length: 10 }, (_, i) => ({ professionalRef: "x", twinId: "t" + i })) }, aggregation: { aggregates: [{}] }, llmCapability: {} };
    const pass99 = Qm.qualifyProcess(Object.assign({}, base, { reviewSet: synthReviewSet(100, 99) })).criteria.find((x) => x.criterion === "reviews_complete").pass;
    assert.equal(pass99, true, "le mutant " + tol + " accepte 99/100 — c'est exactement ce que T39 refuse : la mutation serait detectee");
  }
});

/* ===================== v0.2 — PERSISTANCE DES PREUVES ===================== */
test("T41 le ledger exporte tous les artefacts de preuve (suffisance, pertinence, gate, normalisation, traces) sans secret ; sceau epingle dans l'ancre", async () => {
  const { h, r } = await full("domainA"); const dn = await h.runDownstream(r);
  const all = h.ledger.exportArtifacts();
  const kinds = new Set(Object.values(all).map((e) => e.kind));
  ["corpus-sufficiency", "relevance-evidence", "machine-gate-panel", "coverage-matrix", "twin-set", "review-set", "aggregation", "target-normalization", "enforcement-trace"].forEach((k) => assert.ok(kinds.has(k), k));
  const txt = JSON.stringify(all); assert.equal(/EVIDENCEFORGE_WORKER_API_KEY|sk-ant-|Bearer /.test(txt), false);
  Object.values(all).forEach((e) => assert.equal(h.M10.CANON.artifactHash(e.artifact), e.sha256));
  const led2 = M11.ledger.openMono11Ledger({ manifest: h.manifest, registry: h.registry, RM: h.M10.RM, CANON: h.M10.CANON, sealInfo: { mono11Version: "v0.2", runtimeSealSha256: "a".repeat(64), runCodeHash: "b".repeat(64), mono11ManifestSha256: "c".repeat(64), mono11ZipSha256: "d".repeat(64) } });
  assert.equal(led2.anchor.runtimeSeal.runCodeHash, "b".repeat(64));
});
test("T42 indisponibilite FATALE du fournisseur (credit epuise) -> le run s'arrete fail-closed, aucune passe consommee ; une erreur transitoire consomme une passe", async () => {
  const { h, r } = await full("domainA");
  const { makeDownstreamFakeLlm } = require("./harness.js");
  const base = makeDownstreamFakeLlm();
  const fatal = async (prompt) => { if (prompt.indexOf("EF-03B") !== -1) { const e = new Error("LLM_PROVIDER_CREDIT_EXHAUSTED"); e.fatal = true; throw e; } return base(prompt); };
  await assert.rejects(h.runDownstream(r, { downstreamLlm: fatal, llmCall: fatal }), /LLM_PROVIDER_CREDIT_EXHAUSTED/);
  const { h: h2, r: r2 } = await full("domainA");
  let n = 0; const transient = async (prompt) => { if (prompt.indexOf("EF-03B") !== -1 && n++ === 0) throw new Error("HTTP 503"); return base(prompt); };
  const dn = await h2.runDownstream(r2, { downstreamLlm: transient, llmCall: transient });
  assert.equal(dn.reviewSet.summary.reviewsError, 0);
  const t = dn.enforcementTraces.reviews.find((x) => x.passes[0] && x.passes[0].error); assert.ok(t && t.acceptedPass === 2, "erreur transitoire : passe 1 perdue, passe 2 acceptee");
});
